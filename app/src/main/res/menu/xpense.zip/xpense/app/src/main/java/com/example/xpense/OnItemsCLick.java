package com.example.xpense;

public interface OnItemsCLick {
    void onClick(ExpenseModel expenseModel);
}
